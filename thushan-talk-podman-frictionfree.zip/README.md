# Talk: Mastering Containers with Podman

Presentation slide deck, built with [reveal.js](https://revealjs.com).
